import { useEffect, useState } from "react";
import { useParams, Link, useSearchParams } from "react-router-dom";
import { listDocuments } from "./api";

export default function Viewer() {
  const { documentId } = useParams();
  const [search] = useSearchParams(); // allow ?userId=...
  const userId = search.get("userId") || "u1";

  const [doc, setDoc] = useState(null);
  const [html, setHtml] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await listDocuments(userId);
        const found = (data.items || []).find(d => d.documentId === documentId);
        if (!found) {
          setErr("Document not found.");
          setLoading(false);
          return;
        }
        setDoc(found);

        // If it's HTML, fetch and render it inline
        if ((found.contentType || "").startsWith("text/html") && found.url) {
          const res = await fetch(found.url);
          if (!res.ok) throw new Error(`Fetch failed: ${res.status}`);
          const txt = await res.text();
          setHtml(txt);
        }
      } catch (e) {
        setErr(String(e.message || e));
      } finally {
        setLoading(false);
      }
    })();
  }, [documentId, userId]);

  if (loading) return <div style={styles.shell}><div style={styles.card}>Loading…</div></div>;
  if (err) return (
    <div style={styles.shell}>
      <div style={styles.card}>
        <p style={{color:"#f99"}}>{err}</p>
        <p><Link to="/" style={styles.link}>← Back</Link></p>
      </div>
    </div>
  );

  const isHtml = (doc?.contentType || "").startsWith("text/html");

  return (
    <div style={styles.shell}>
      <div style={{...styles.card, maxWidth: "min(1100px, 96vw)"}}>
        <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
          <h2 style={{margin:0}}>Viewer</h2>
          <Link to="/" style={styles.link}>← Back</Link>
        </div>
        <div style={{marginTop:10, color:"#9aa6be", fontSize:13}}>
          {doc?.s3Key} • {doc?.contentType} • {doc?.documentId}
        </div>

        {!isHtml && doc?.url && (
          <div style={{marginTop:16}}>
            <a href={doc.url} target="_blank" rel="noreferrer" style={styles.btn}>Open file</a>
          </div>
        )}

        {isHtml && (
          <div
            style={styles.htmlWrap}
            dangerouslySetInnerHTML={{ __html: html }}
          />
        )}
      </div>
    </div>
  );
}

const styles = {
  shell: { background:"#0b1220", minHeight:"100vh", padding:"24px" },
  card: {
    background:"rgba(18,26,43,0.92)", border:"1px solid #1f2a44",
    borderRadius:16, padding:20, margin:"0 auto", maxWidth:900
  },
  link: { color:"#98b7ff", textDecoration:"none" },
  btn: {
    background:"#2fe6a7", border:"1px solid #2fe6a7", color:"#06291f",
    padding:"10px 12px", borderRadius:10, textDecoration:"none", fontWeight:600
  },
  htmlWrap: {
    marginTop:18,
    background:"#0f1626",
    border:"1px solid #233056",
    borderRadius:12,
    padding:16,
    overflowX:"auto",
  }
};
